App({
  globalData: {},
  onCreate() {},
  onDestroy() {},
})
