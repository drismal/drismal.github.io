try {
  (() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp
    __$$app$$__.__globals__ = {
      lang: new DeviceRuntimeCore.HmUtils.Lang(DeviceRuntimeCore.HmUtils.getLanguage()),
      px: DeviceRuntimeCore.HmUtils.getPx(480),
    }
    __$$app$$__.app = DeviceRuntimeCore.App({
      globalData: {},
      onCreate() {},
      onDestroy() {},
    })
  })()
} catch (e) {
  console.log('Mini Program Error', e)
}
